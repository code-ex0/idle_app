import 'package:flutter/material.dart';
import 'package:test_1/component/market/item.component.dart';

class MarketPage extends StatelessWidget {
  const MarketPage({super.key});

  static const listItem = ['wood', 'stone', 'iron', 'gold'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Marché')),
      // loop on item cards
      body: ListView.builder(
        itemCount: listItem.length,
        itemBuilder: (context, index) {
          return Item(name: listItem[index]);
        },
      ),
    );
  }
}
