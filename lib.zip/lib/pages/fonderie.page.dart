import 'package:flutter/material.dart';

class FonderiePage extends StatelessWidget {
  const FonderiePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fonderie')),
      body: const Center(child: Text('Ici la gestion de la Fonderie')),
    );
  }
}
