import 'package:flutter/material.dart';

class ArtisanatPage extends StatelessWidget {
  const ArtisanatPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Artisanat')),
      body: const Center(child: Text('Ici la gestion de l\'Artisanat')),
    );
  }
}
