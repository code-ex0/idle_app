import 'package:flutter/material.dart';

class ScieriePage extends StatelessWidget {
  const ScieriePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scierie')),
      body: const Center(child: Text('Ici la gestion de la Scierie')),
    );
  }
}
