// card of shop item

import 'package:flutter/material.dart';

class Item extends StatelessWidget {
  const Item({super.key, required this.name});
  final String name;
  // todo

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: <Widget>[
          ListTile(title: Text(name), subtitle: const Text('Prix: 1000')),
          OverflowBar(
            children: <Widget>[
              TextButton(
                onPressed: () {
                  // Perform some action
                },
                child: const Text('Acheter'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
