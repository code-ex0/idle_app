import 'package:flutter/material.dart';

class GameState extends ChangeNotifier {
  int _gold = 0;

  int get gold => _gold;

  void addGold(int amount) {
    _gold += amount;
    notifyListeners();
  }

  void removeGold(int amount) {
    _gold -= amount;
    notifyListeners();
  }
}
